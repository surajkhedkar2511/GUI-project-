# Java OOP Quiz Application

## Project Overview
A single-file, web-based quiz application for practicing Java Object-Oriented Programming concepts. It uses HTML for structure, CSS for styling, and JavaScript for quiz logic.

## Features
- Student name entry
- 10 multiple-choice questions about Java OOP
- Four options per question
- 60-second countdown timer
- Progress bar and question counter
- Automatic score and percentage calculation
- Result message and restart option
- Responsive layout

## Topics Covered
Classes and objects, inheritance, polymorphism, encapsulation, constructors, method overloading, interfaces, and exception handling.

## How to Run
1. Extract the ZIP file.
2. Open `QuizApplication.html` in a modern web browser (Chrome, Edge, Firefox, etc.).
3. Enter a student name and select **Start Quiz**.
4. Answer each question and view the result at the end.

No installation, server, internet connection, or database is required.

## Technologies
- HTML5
- CSS3
- JavaScript

## Project Details
- Activity: CIE-2 Activity-6 – OOP GUI Application
- Project: Java OOP Quiz Application
- Developed by: Suraj Khedkar
- Roll Number: IT2148
